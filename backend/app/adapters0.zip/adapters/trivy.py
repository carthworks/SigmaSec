# app/adapters/trivy.py

import json
import subprocess
import uuid
from typing import List

from app.adapters.base import BaseAdapter

TRIVY_BINARY = "/usr/bin/trivy"
TIMEOUT_SECONDS = 600
CYBERSIGMA_USER_AGENT = "CyberSigma-Scanner/0.1.0 (+https://cybersigma.io/scanner)"

SEVERITY_MAP = {
    "CRITICAL": "critical",
    "HIGH": "high",
    "MEDIUM": "medium",
    "LOW": "low",
    "UNKNOWN": "info",
}


class TrivyAdapter(BaseAdapter):
    """
    Runs Trivy SCA scanner against a Docker image.
    Parses CVE findings and extracts fixed_version.
    fixed_version stored in metadata JSONB for UI badge.
    """

    def run(
        self,
        target: str,
        scan_id: str,
        org_id: str,
        asset_id: str,
        options: dict = None,
    ) -> List[dict]:
        cmd = [
            TRIVY_BINARY,
            "image",
            "--format",
            "json",
            "--severity",
            "LOW,MEDIUM,HIGH,CRITICAL",
            "--quiet",
            target,
        ]

        print(f"[TrivyAdapter] Running: {' '.join(cmd)}")

        try:
            from app.adapters.runner import run_logged_command
            import os
            env = os.environ.copy()
            env["TRIVY_USERAGENT"] = CYBERSIGMA_USER_AGENT
            stdout_content = run_logged_command(
                scan_id=scan_id,
                cmd=cmd,
                timeout=TIMEOUT_SECONDS,
                env=env,
            )
        except Exception as e:
            print(f"[TrivyAdapter] Error during scanner run: {e}")
            return []

        if not stdout_content.strip():
            print("[TrivyAdapter] Empty output")
            return []

        try:
            data = json.loads(stdout_content)
        except json.JSONDecodeError as e:
            print(f"[TrivyAdapter] JSON parse error: {e}")
            return []

        findings = []
        for result_block in data.get("Results", []):
            vulns = result_block.get("Vulnerabilities") or []
            for vuln in vulns:
                finding = self._parse_finding(
                    vuln, scan_id, org_id, asset_id, result_block
                )
                if finding:
                    findings.append(finding)

        print(f"[TrivyAdapter] Found {len(findings)} findings")
        return findings

    def _parse_finding(
        self,
        vuln: dict,
        scan_id: str,
        org_id: str,
        asset_id: str,
        result_block: dict,
    ) -> dict | None:
        severity_raw = vuln.get("Severity", "UNKNOWN")

        return {
            "id": str(uuid.uuid4()),
            "org_id": org_id,
            "scan_id": scan_id,
            "asset_id": asset_id,
            "title": vuln.get("Title") or vuln.get("VulnerabilityID", "Unknown"),
            "severity": SEVERITY_MAP.get(severity_raw, "info"),
            "cve_id": vuln.get("VulnerabilityID"),
            "tool": "trivy",
            "url": "",
            "description": vuln.get("Description", ""),
            "metadata": {
                "fixed_version": vuln.get("FixedVersion", ""),
                "installed_version": vuln.get("InstalledVersion", ""),
                "package": vuln.get("PkgName", ""),
                "target": result_block.get("Target", ""),
                "type": result_block.get("Type", ""),
                "references": vuln.get("References", []),
            },
        }
