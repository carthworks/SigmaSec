import os
import json
import shutil
import logging
import subprocess
import uuid
import hashlib

from app.adapters.base import BaseAdapter

logger = logging.getLogger(__name__)


class GitleaksAdapter(BaseAdapter):
    def __init__(self, binary_path: str = "gitleaks"):
        # Check /app/tools/gitleaks first, fallback to shutil.which or global
        self.binary_path = (
            shutil.which(binary_path) 
            or (shutil.which("/app/tools/gitleaks"))
            or "/usr/local/bin/gitleaks"
        )

    def mask_secret(self, secret: str) -> str:
        if not secret:
            return ""
        secret = secret.strip()
        if len(secret) <= 8:
            return secret[:2] + "..." + secret[-2:] if len(secret) > 4 else "******"
        return secret[:4] + "..." + secret[-4:]

    def run(
        self,
        target: str,
        scan_id: str,
        org_id: str,
        asset_id: str,
        options: dict = None,
    ) -> list[dict]:
        """
        Clones repository target to a temporary folder, runs Gitleaks,
        parses the results, and deletes the workspace afterwards.
        """
        scan_dir = f"/tmp/scan_{scan_id}"
        report_file = f"/tmp/report_{scan_id}.json"
        
        # Ensure we start clean
        if os.path.exists(scan_dir):
            shutil.rmtree(scan_dir)
        if os.path.exists(report_file):
            try:
                os.remove(report_file)
            except Exception:
                pass

        logger.info(f"Cloning {target} to {scan_dir} with depth 50...")
        try:
            from app.adapters.runner import run_logged_command
            # Clone repo shallow: --depth 50
            clone_cmd = ["git", "clone", "--depth", "50", target, scan_dir]
            run_logged_command(scan_id=scan_id, cmd=clone_cmd, capture_stdout=False)
            if not os.path.exists(scan_dir):
                raise Exception("Git clone target directory was not created.")
        except Exception as e:
            logger.error(f"Failed to clone repository {target}: {e}")
            raise Exception(f"Failed to clone target repository: {e}")

        # Run Gitleaks detect
        gitleaks_cmd = [
            self.binary_path,
            "detect",
            f"--source={scan_dir}",
            "--report-format=json",
            f"--report-path={report_file}",
            "--no-git=false" # Scan git history if git files exist
        ]

        logger.info(f"Executing Gitleaks: {' '.join(gitleaks_cmd)}")

        try:
            from app.adapters.runner import run_logged_command
            # Gitleaks exits with non-zero (often 1) when leaks are found
            run_logged_command(scan_id=scan_id, cmd=gitleaks_cmd, capture_stdout=False)

            # Read report file
            if os.path.exists(report_file):
                with open(report_file, "r") as f:
                    content = f.read()
                return self.parse(content, scan_id, org_id, asset_id)
            
            # If no report file is generated, Gitleaks found no secrets
            return []

        except Exception as e:
            logger.error(f"Gitleaks scan failed: {str(e)}")
            raise
        finally:
            # CLEANUP: shutil.rmtree(/tmp/scan_{id}) in finally block
            if os.path.exists(scan_dir):
                try:
                    shutil.rmtree(scan_dir)
                    logger.info(f"Cleaned up scan repository directory: {scan_dir}")
                except Exception as ex:
                    logger.error(f"Failed to clean up scan dir {scan_dir}: {str(ex)}")
            
            if os.path.exists(report_file):
                try:
                    os.remove(report_file)
                except Exception as ex:
                    pass

    def parse(
        self,
        json_data: str,
        scan_id: str = None,
        org_id: str = None,
        asset_id: str = None,
    ) -> list[dict]:
        if not json_data or not json_data.strip():
            return []

        try:
            findings_raw = json.loads(json_data)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse Gitleaks JSON report: {e}")
            return []

        fingerprint_map = {}
        for f in findings_raw:
            secret_type = f.get("Description", "Secret Leak")
            file_path = f.get("File", "unknown")
            line_no = f.get("StartLine", 1)
            commit = f.get("Commit", "N/A")
            raw_secret = f.get("Secret", "")
            
            # Calculate SHA256 fingerprint of normalized (stripped) secret
            normalized_secret = raw_secret.strip()
            secret_fingerprint = hashlib.sha256(normalized_secret.encode("utf-8")).hexdigest()
            
            masked_secret = self.mask_secret(raw_secret)
            
            occurrence = {
                "file": file_path,
                "line": line_no,
                "commit": commit,
                "author": f.get("Author", "N/A"),
                "date": f.get("Date", "N/A")
            }

            if secret_fingerprint in fingerprint_map:
                # Add duplicate secret occurrences
                existing_metadata = fingerprint_map[secret_fingerprint]["metadata"]
                if occurrence not in existing_metadata["occurrences"]:
                    existing_metadata["occurrences"].append(occurrence)
            else:
                title = f"Secret Detected: {secret_type}"
                description = (
                    f"A potential plaintext secret has been leaked in file '{file_path}' "
                    f"on line {line_no}. Rule trigger: '{f.get('RuleID', 'unknown')}'."
                )
                
                metadata = {
                    "secret_type": secret_type,
                    "partial_secret": masked_secret,
                    "fingerprint": secret_fingerprint,
                    "occurrences": [occurrence],
                    # Standard keys for backward compatibility
                    "file": file_path,
                    "line": line_no,
                    "commit": commit,
                    "author": f.get("Author", "N/A"),
                    "date": f.get("Date", "N/A")
                }

                finding = {
                    "id": str(uuid.uuid4()) if scan_id else None,
                    "org_id": org_id,
                    "scan_id": scan_id,
                    "asset_id": asset_id,
                    "title": title,
                    "severity": "critical",
                    "cve_id": None,
                    "tool": "gitleaks",
                    "url": f"{file_path}#L{line_no}",
                    "description": description,
                    "metadata": metadata,
                    "scan_metadata": metadata  # Maintain compatibility with test_integration.py asserts
                }
                fingerprint_map[secret_fingerprint] = finding

        return list(fingerprint_map.values())

