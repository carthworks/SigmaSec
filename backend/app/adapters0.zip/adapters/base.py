# app/adapters/base.py

from abc import ABC, abstractmethod
from typing import List


class BaseAdapter(ABC):
    """
    Abstract base class for all scanner adapters.
    Every scanner (Nuclei, Trivy, Gitleaks) implements this.
    Week 3: Nuclei + Trivy
    Week 4: Gitleaks
    """

    @abstractmethod
    def run(
        self,
        target: str,
        scan_id: str,
        org_id: str,
        asset_id: str,
        options: dict = None,
    ) -> List[dict]:
        """
        Run the scanner against target.
        Returns list of finding dicts ready to insert into DB.
        Must handle: timeout, non-zero exit, partial output.
        Must NOT raise — return empty list on failure.
        """
        pass

    def safe_run(
        self,
        target: str,
        scan_id: str,
        org_id: str,
        asset_id: str,
        options: dict = None,
    ) -> List[dict]:
        """
        Wrapper that catches all exceptions.
        One adapter failing must NOT kill the whole scan.
        """
        try:
            return self.run(target, scan_id, org_id, asset_id, options or {})
        except Exception as e:
            print(f"[{self.__class__.__name__}] ERROR: {e}")
            return []
