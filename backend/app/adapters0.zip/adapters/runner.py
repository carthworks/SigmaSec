import os
import subprocess
import select
import logging
import redis

logger = logging.getLogger(__name__)


def run_logged_command(
    scan_id: str,
    cmd: list,
    timeout: int = 600,
    capture_stdout: bool = True,
    cwd: str = None,
    env: dict = None,
) -> str:
    """
    Runs a shell command. Captures its stderr (and stdout if not captured separately for parsing)
    and streams each line directly to Redis `scan:{scan_id}:logs`.
    Returns the accumulated stdout string.
    """
    r = redis.from_url(
        os.environ.get("REDIS_URL", "redis://redis:6379"), decode_responses=True
    )

    r.rpush(f"scan:{scan_id}:logs", f"[system] Launching: {' '.join(cmd)}")

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        cwd=cwd,
        env=env,  # None means inherit from parent process
    )


    stdout_lines = []
    active_pipes = [process.stdout, process.stderr]

    try:
        while active_pipes:
            # Wait for data on any active pipe
            r_list, _, _ = select.select(active_pipes, [], [], 0.5)
            if not r_list:
                if process.poll() is not None:
                    break
                continue

            for pipe in r_list:
                line = pipe.readline()
                if not line:
                    # EOF reached on this pipe, remove it from select tracking
                    active_pipes.remove(pipe)
                    continue
                cleaned = line.strip()
                if not cleaned:
                    continue

                if pipe == process.stdout:
                    if capture_stdout:
                        stdout_lines.append(line)
                    # Exclude huge JSON data dumps from the logs feed
                    if len(cleaned) < 500 and not (
                        cleaned.startswith("{") or cleaned.startswith("[")
                    ):
                        r.rpush(f"scan:{scan_id}:logs", f"[stdout] {cleaned}")
                else:
                    r.rpush(f"scan:{scan_id}:logs", f"[stderr] {cleaned}")
    except Exception as e:
        r.rpush(
            f"scan:{scan_id}:logs",
            f"[system] Scanner fallback execution reader: {e}",
        )
        stdout_data, stderr_data = process.communicate(timeout=timeout)
        if capture_stdout:
            stdout_lines = [stdout_data]
        for line in stderr_data.splitlines():
            cleaned = line.strip()
            if cleaned:
                r.rpush(f"scan:{scan_id}:logs", f"[stderr] {cleaned}")

    process.wait(timeout=timeout)
    r.rpush(
        f"scan:{scan_id}:logs",
        f"[system] Scanner execution completed. Status: {process.returncode}",
    )
    return "".join(stdout_lines)
