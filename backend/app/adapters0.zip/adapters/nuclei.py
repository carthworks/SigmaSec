# app/adapters/nuclei.py

import json
import subprocess
import uuid
from typing import List

from app.adapters.base import BaseAdapter

# Severity mapping from nuclei to our internal enum
SEVERITY_MAP = {
    "critical": "critical",
    "high": "high",
    "medium": "medium",
    "low": "low",
    "info": "info",
    "unknown": "info",
}

NUCLEI_BINARY = "/usr/local/bin/nuclei"
TIMEOUT_SECONDS = 600  # 10 minutes max per scan
CYBERSIGMA_USER_AGENT = "CyberSigma-Scanner/0.1.0 (+https://cybersigma.io/scanner)"


class NucleiAdapter(BaseAdapter):
    """
    Runs Nuclei vulnerability scanner against a web target.
    Parses JSONL output (one JSON object per line).
    FR-SCN-13: When validate=True, runs with -validate flag and marks exploit_validated=True.
    """

    def run(
        self,
        target: str,
        scan_id: str,
        org_id: str,
        asset_id: str,
        options: dict = None,
    ) -> List[dict]:
        options = options or {}
        validate = options.get("validate", False)

        cmd = [
            NUCLEI_BINARY,
            "-target",
            target,
            "-t",
            "cves,vulnerabilities",
            "-jsonl",
            "-silent",
            "-no-color",
            "-timeout",
            "10",
            "-retries",
            "1",
            # FR-SCN-13: identify our scanner in outbound requests
            "-H",
            f"User-Agent: {CYBERSIGMA_USER_AGENT}",
        ]

        if validate:
            # FR-SCN-13: active exploit confirmation mode
            cmd.append("-validate")

        print(f"[NucleiAdapter] Running: {' '.join(cmd)}")

        try:
            from app.adapters.runner import run_logged_command
            stdout_content = run_logged_command(
                scan_id=scan_id,
                cmd=cmd,
                timeout=TIMEOUT_SECONDS,
            )
        except Exception as e:
            print(f"[NucleiAdapter] Error during scanner run: {e}")
            return []

        findings = []
        for line in stdout_content.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                finding = self._parse_finding(
                    data, scan_id, org_id, asset_id, validate_mode=validate
                )
                if finding:
                    findings.append(finding)
            except json.JSONDecodeError:
                continue  # skip malformed lines

        print(f"[NucleiAdapter] Found {len(findings)} findings (validate_mode={validate})")
        return findings

    def _parse_finding(
        self,
        data: dict,
        scan_id: str,
        org_id: str,
        asset_id: str,
        validate_mode: bool = False,
    ) -> dict | None:
        info = data.get("info", {})
        severity_raw = info.get("severity", "info").lower()

        # Extract CVE id if present
        cve_id = None
        classification = info.get("classification", {})
        cve_ids = classification.get("cve-id", [])
        if cve_ids:
            cve_id = cve_ids[0] if isinstance(cve_ids, list) else cve_ids

        severity = SEVERITY_MAP.get(severity_raw, "info")

        # FR-SCN-13: In validate mode, all returned findings are confirmed exploitable.
        # Non-validated critical findings get a -0.2 priority penalty in save_findings.
        exploit_validated = validate_mode

        return {
            "id": str(uuid.uuid4()),
            "org_id": org_id,
            "scan_id": scan_id,
            "asset_id": asset_id,
            "title": info.get("name", data.get("template-id", "Unknown")),
            "severity": severity,
            "cve_id": cve_id,
            "tool": "nuclei",
            "url": data.get("matched-at", ""),
            "description": info.get("description", ""),
            "exploit_validated": exploit_validated,
            "metadata": {
                "template_id": data.get("template-id", ""),
                "host": data.get("host", ""),
                "tags": info.get("tags", []),
                "reference": info.get("reference", []),
                "validate_mode": validate_mode,
            },
        }
